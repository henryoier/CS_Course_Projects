/* global jasmine */

jasmine.getFixtures().fixturesPath = 'test/fixtures'
jasmine.getEnv().defaultTimeoutInterval = 1000
